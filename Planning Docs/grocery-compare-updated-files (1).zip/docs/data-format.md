# Data format

This page is for whoever supplies prices. The app reads one generated file, `data/data.js`. You never edit that file. You edit `data/products.csv` and `data/config.json`, then run `npm run build-data`.

## products.csv

One row per product. Columns:

| Column | Required | Meaning |
| --- | --- | --- |
| `id` | yes | Unique whole number. Never reuse an id, because saved lists in people's browsers point to it |
| `name` | yes | Shown on the card |
| `category` | yes | Must match a category in `config.json` (not "All") |
| `size` | yes | For example `2 L` |
| `divisor` | yes | Price is divided by this for the unit price. 2 L milk has divisor 2 |
| `unit` | yes | Shown after the unit price, for example `/L` |
| `brand` | yes | Part of the matching rule and of search |
| `barcode` | no | GTIN 8, 12, 13 or 14 digits. The validator checks the check digit |
| `price:<store>` | at least 2 stores | Regular shelf price in rands. Leave blank if the store does not stock it |
| `special:<store>` | no | Loyalty card price. Must be lower than the regular price |
| `until:<store>` | no | Last day the special is valid, `YYYY-MM-DD`. After that day the app hides the special |

Matching rule: same barcode, or same brand, type and size.

## config.json

Stores, colours, loyalty card names, categories, branches and the `updated` date (`YYYY-MM-DD`).

Each branch is `[name, latitude, longitude, price factor]`.

- Put the suburb or town in the branch name. Branch search only looks at the name.
- The first branch of each store is the default for people who do not pick one or share their location. Make it a central, busy branch.
- The price factor multiplies the store's prices for that branch. Until real branch prices exist this is a sample factor.

## What the app does with a store that has no branch near the user

If the user shares their location and a store has no branch within 75 km, that store keeps the branch it already had and the page says so.

## Special end dates: one change needed in tools/import.js

The app and `tools/validate.js` already understand special end dates. They are read from a `su` object on each product, shaped like `sp`:

```js
{ id: 1, n: "Full cream milk", p: { ... }, sp: { "Checkers": 29.99 }, su: { "Checkers": "2026-11-02" } }
```

`tools/import.js` has to copy the new `until:<store>` column into `su`. Where it builds `sp` for a store, add the same for `su`. Adapt the variable names to match that file:

```js
if (row["until:" + store]) { (product.su = product.su || {})[store] = row["until:" + store].trim(); }
```

Until that is added, specials simply have no end date and stay visible, as before.

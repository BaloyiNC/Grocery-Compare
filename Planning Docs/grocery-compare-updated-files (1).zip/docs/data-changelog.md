# Data changelog

Add one entry per refresh, newest first. This is what you read when something looks wrong and you need to know what changed and when.

## Template

```
## YYYY-MM-DD
Source: where the prices came from (feed, licence, manual capture, who captured them)
Changed: number of products, anything unusual (new items, removed items, big price jumps)
Specials: how many, and the end dates if known
Notes: anything the next person should know
```

## Entries

Sample data only so far. No real refresh has been done.

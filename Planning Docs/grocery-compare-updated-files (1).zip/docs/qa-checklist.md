# QA record (sprint 8)

## Checked by the automated tests (`npm test`)

Adding, quantities and the 99 cap, focus staying on the button you pressed, saved state, damaged saved state, store totals, missing items, loyalty totals, expired specials, branch search, nothing nearby, old data warning, names with quotes or tags in them, the remove button, screen reader labels, and speed with about 4,000 products (the page draws 60 cards at a time).

## Colour contrast

Ratio of text colour to the colour behind it. WCAG AA asks for 4.5 or more for small text.

| Pair | Ratio | Result |
| --- | --- | --- |
| White text on Ember Orange (buttons, chips) | 3.22 | Below 4.5 |
| Ember Orange text on white (list badge) | 3.22 | Below 4.5 |
| Verdant Green on white (cheapest price) | 2.79 | Below 4.5 |
| Verdant Green on a grey card ("Save up to") | 2.56 | Below 4.5 |
| Purple special price on white | 5.36 | Pass |
| Grey caption on white | 5.33 | Pass |
| Grey caption on a grey card | 4.89 | Pass |
| Main text on white | 13.39 | Pass |
| Dark mode: green on the page | 8.91 | Pass |
| Dark mode: purple on the page | 6.74 | Pass |
| Dark mode: grey caption on a card | 5.38 | Pass |
| Dark mode: main text on the page | 16.16 | Pass |
| Dark mode: white text on Ember Orange | 3.22 | Below 4.5 |

The orange and the green are the brand colours in the design guide and were kept on purpose. The decision still needs an owner: keep them, or use a darker orange for button backgrounds and a darker green for small price text.

## Still to do by hand (a script cannot do these)

- [ ] Phone widths: 360, 390 and 768 px in the Chrome device toolbar, then at least two real phones
- [ ] Chrome, Safari, Firefox and Edge
- [ ] Keyboard only: Tab through the page, add an item, change its quantity, remove it, switch a store chip, open the branch panel
- [ ] Screen reader: one quick pass with VoiceOver or TalkBack on the add button, quantity buttons and chips
- [ ] Offline: load the page once, switch off the network, reload
- [ ] Cleared storage: clear site data and reload
- [ ] Use my location on a real phone, once allowed and once denied

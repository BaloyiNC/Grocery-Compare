# Maintenance guide

Follow each list in order. Do not skip steps.

## Refresh prices (every 2 weeks)

1. Replace `data/products.csv` with the new prices.
2. Open `data/config.json` and set `"updated"` to today, written `YYYY-MM-DD`.
3. In a terminal, in the project folder, run `npm run build-data`. It imports, then validates. If it prints errors, fix the lines it names and run it again.
4. Run `npm test`. Every line should say PASS.
5. Add an entry at the top of `docs/data-changelog.md` (date, source, what changed).
6. Commit and push.

If a refresh turns out to be wrong, see "Roll back a bad refresh" below.

## Roll back a bad refresh

1. Run `git log --oneline data/` and find the commit before the bad refresh.
2. Run `git revert <the bad commit id>`.
3. Run `npm run build-data` and `npm test`, then push.
4. Add a line to `docs/data-changelog.md` saying the refresh was rolled back and why.

## Add a store

1. In `data/config.json` add the store name to the stores list, then give it a colour, a loyalty card name and a list of branches.
2. In `data/products.csv` add `price:<store>` and `special:<store>` columns, and fill them.
3. Open `tools/import.js` and check whether store names are written inside it. If they are, add the new one there too.
4. In `index.html` the hero line names the four stores. Update that sentence.
5. Run `npm run build-data` and `npm test`.

## Add a category

1. In `data/config.json` add the name to the categories list, after "All".
2. Give at least one product that category in `data/products.csv`. The validator warns when a category has no products.
3. Run `npm run build-data` and `npm test`.

## Add a branch

1. In `data/config.json` add `[name, latitude, longitude, price factor]` to that store's list. Put the suburb or town in the name.
2. Run `npm run build-data`.

## Release v1.0.0

1. Make sure `npm run build-data` and `npm test` both pass and everything is committed.
2. Run `git tag -a v1.0.0 -m "First release"`.
3. Run `git push origin v1.0.0`.

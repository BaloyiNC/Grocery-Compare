# Backlog for after v1.0.0

Ideas that are deliberately not in version 1.

- Price history per item and store, built from the data changelog or stored snapshots
- Price drop alerts
- User accounts, only if keeping the list in the browser stops being enough
- Real branch level prices (branches use a sample price factor today)
- A real price source (see the Price source section in the README)
- Privacy friendly analytics, if wanted. This needs a yes or no decision first
